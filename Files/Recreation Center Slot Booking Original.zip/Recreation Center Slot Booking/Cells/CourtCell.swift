 
import UIKit

class CourtCell: UICollectionViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    

}
